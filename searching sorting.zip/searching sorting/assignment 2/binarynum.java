import java.util.Scanner;

public class binar10ynum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int number = scanner.nextInt();
        scanner.close();

        String binary = Integer.toBinaryString(number);
        System.out.println("Binary representation: " + binary);
    }
}
